# Independent QA report — task-5

Status: completed for the assigned classification review. Skill used: oma-qa,
including its execution protocol and applicable security, performance, compatibility
and test checklist items. Reviewer is independent of the implementation owner.
Owned writes are confined to review/ and verification/ under this evidence directory.
No product source, test, manifest, lockfile, migration, harness, specification,
preceding Actor report or mission state was edited.

## Review Result: PASS for the documented classification slice

Verification completeness: completed for task-5. No CRITICAL, HIGH, MEDIUM or LOW
implementation findings were reproduced. No product repair is requested. This is
not a claim that the harness passed, that all ARC requirements are met, or that the
Chief's final mission verification is complete. The harness actually exits 1 with
one unresolved coverage failure: `error: Script not found "test:coverage"`.
The task explicitly requires retaining that failure. `blockersResolved=true` in
summary.json means no unresolved blocker in this assigned slice; it does not close
the coverage obligation or certify downstream final-delivery artifacts.

## Inputs and inspection

Current HEAD is the accepted baseline
05f0812d0841485bbe07b3f1f8f6fde3861a1d55. Existing uncommitted implementation changes
and untracked detector/tests/evidence were inspected first. The scoped Git diff adds
arc-detector, typed protocol-1 job.classify, arcctl classify, and additive dependency
edges using existing Serde/serde_json. No third-party package/version upgrade appears
in the lockfile diff. Existing task-4 handoff evidence was consumed as historical
evidence and checked against current files; its pass claim did not substitute for
fresh independent tests.

The amended contract.md/contract.json and synchronized cli-requirements.md agree
with the observed request schema, result enum vocabulary, CLI output and failure
ordering. The 68 shared observations and ten malformed payload cases are compared
against actual detector/IPC/daemon/CLI results. The matrix in
verification/test-matrix.md names the exact executable tests and maps each required
behavior and preservation obligation to assertions inspected in source.

Serena tool discovery returned no tools. Inspection used direct reads of known
paths, the Git diff, and file inventories; no native code-content search replaced
the required provider. The configuration file .agents/oma-config.yaml is absent;
the existing CUE schema was readable. Memory search supplied no relevant ARC facts.
Global Git inspection reports `av.yaml: Operation not permitted`, so no globally
clean-worktree claim is made. Shell startup emits a mise tracking-link warning.
Neither limitation was bypassed or repaired; all required commands ran successfully
apart from the retained harness coverage failure.

## Security and correctness evidence

| Source | Independent observation |
| --- | --- |
| crates/arc-detector/src/lib.rs:20; types.rs; Cargo.toml | Pure in-memory syntax analysis. Production dependency is Serde only. No process, filesystem, environment, resolver, transport, logging or storage APIs occur in the production detector modules. Results contain only four closed enum fields. UNKNOWN always pairs with UNKNOWN locality and OBSERVE. |
| crates/arc-detector/src/lexer.rs:27 | Byte lookahead, decoded-byte copies and UTF-8 validation are charged before operations. Quote/escape provenance prevents operators/command-like arguments becoming invocations. Active expansion returns uncertainty without evaluation. Unsupported shell syntax is rejected conservatively. |
| crates/arc-detector/src/parser.rs; rules.rs | Only invocation-position literal words select Cargo/gh/SSH rules. Only the documented three-word shell wrappers recurse. Arbitrary quoted arguments and SSH remote text remain opaque. Flattened leaves aggregate at the root, and any unresolved stage keeps the whole compound uncertain. SSH option values remain opaque; Docker always remains unresolved. No tool/config/script discovery. |
| crates/arc-detector/src/budget.rs:3 | Original command bytes are checked before shell handling or scan. Token, invocation, active nesting and work limits are shared through nested passes. Checked work addition refuses overrun/overflow before its operation. Allocation and scans remain bounded by input/tokens/work, with no repeated front removal or unbounded parser recursion. |
| crates/arc-ipc/src/lib.rs:310 | Existing dispatch signature and protocol version 1 remain. Version guard runs before typed payload validation. Classification never invokes the doctor callback. Strict payload rejects unknown keys/type/null errors; legacy envelope behavior remains. |
| crates/arc-daemon/src/connection.rs:97 | Analysis runs synchronously within existing admitted request handling. The frame body is dropped, classification's decoded input drops on dispatch return, and request payload is replaced with null before response await. Raw input never reaches DbWorker, diagnostic reports or logging. Ordinary operations still dispose payload before database await. Dropping memory is not secure erasure. |
| crates/arc-daemon/src/admission.rs:44; platform.rs:11 | Native peer identity is checked before constructing a handler. Existing same-user implementation and admission file are byte-equal to baseline. No new path bypasses authentication or expands permissions. |
| crates/arc-cli/src/classify.rs; main.rs | Sends exactly one command argument as data through local IPC. Fixed errors, generated IDs and closed results avoid raw input reflection. Response protocol, correlation, status, schema and valid enum combinations are checked before stdout. Help explains caller-side quoting. No shell invocation, retry or daemon auto-start. |

The unchanged privacy.rs SHA-256 is
3c7fd3ba43eded12ddaa071cbce6553c05370fe3898f4034912a6653620eadee.
Its required TCP test and all assertions remain present. Both TCP and Unix privacy
tests actually ran. Each exercises twelve input families through the real daemon
and both real CLI output modes. The assertions check private tool traps, active,
literal, nested and backtick substitution markers, monitored endpoints, response
and output canaries, captured daemon logs, reports, database and live WAL/SHM, before,
during and after shutdown. Fixture receipts report zero started traps, substitution
markers, endpoint contacts and persisted canaries; classification-only DB high-water
is zero. Static call-path inspection supports these negative probes. They establish
the specified cases and pure boundary, not every possible shell program.

## Commands executed and outcomes

All checks ran from the supplied mission workspace through supported noninteractive
exec_command, as effective UID 501 on macOS arm64. No credentials, GUI workaround,
policy change, download, installation, standalone build or external delivery was
used. Cargo was offline. Checks ran serially with 120-second per-command deadlines.
Each command has exact argv, cwd, context, start/end timestamps, actual exit, complete
combined stdout/stderr, its hash, and 79 before/after source/specification entries.
All command inputs remained identical. Logs and receipts are in verification/.

| Command | Actual result | Receipt / log |
| --- | --- | --- |
| Fresh socket bind/listen 127.0.0.1:0, then close owned monitor | Permitted in current context, after operator environment note | tcp-prerequisite.json |
| cargo test -p arc-daemon --test classification privacy::required_loopback_endpoint_nonexecution_and_privacy -- --exact | Exit 0; 1 passed | privacy.json / privacy.txt |
| cargo fmt --all -- --check | Exit 0 | fmt.json / fmt.txt |
| cargo clippy --workspace --all-targets -- -D warnings | Exit 0 | clippy.json / clippy.txt |
| cargo test --workspace | Exit 0; 205 passed, zero failed/ignored | workspace-tests.json / workspace-tests.txt |
| ./scripts/harness/validate.sh | Exit 1; one missing test:coverage violation; other four checks reported no violation; no skip | harness.json / harness.txt |
| cargo test -p arc-detector tests::production_work_exhaustion_trace -- --exact --nocapture | Exit 0; 1 passed; captures the counter trace suppressed by normal passing-test output | work-trace.json / work-trace.txt |
| git diff --check | Exit 0; no whitespace diagnostics; av.yaml access diagnostic retained as scope limitation | Executed during inspection |

The existing production trace uses 12033 bytes and records work=60203, tokens=6,
invocations=2, max_depth=1 before a bulk precharge fails with WORK_LIMIT. Other caps
remain below their maxima, and repeated analysis returns identical counters. A
failed bulk charge need not fill the counter to 65536. No production cap was lowered.

## Runtime and compatibility

Actual subprocess coverage includes all seven daemon classification tests and all
four CLI-specific tests, alongside eight detector units and three IPC classification
tests. The daemon matrix invokes both human and JSON arcctl for every observation.
The fake-peer CLI tests separately exercise malformed/untrusted responses, timeouts,
request correlation, input-free errors and recovery.

Fresh saturation receipts record 77 completed classifications, continuing traffic,
same-connection malformed recovery in 9166 microseconds, maximum health latency
6012 microseconds over ten successful health requests, and signal-to-exit 11016
microseconds. The test requires SIGTERM within 3500000 microseconds and existing
health/recovery deadlines. Shutdown accounting shows all handlers reaped, one worker
joined, zero gauges, socket removed and deadline met. Limits remain 64 connections,
16 requests, queue 8, frame 1048576 bytes, shutdown 3500 ms; no limit was widened.
These values describe one recorded debug test run, not a general performance claim.

Protocol, status, doctor, native same-user socket acceptance, invalid socket rejection,
foreign-directory ownership policy, admission races/load, frame/deadline handling,
health during database stalls and shutdown regressions pass. Source inspection and
baseline byte equality establish the unchanged native peer-UID rejection branch.
No live foreign-account peer impersonation was attempted or claimed. This does not
prevent verifying that the existing same-user authentication mechanism is preserved.

Terminal output is linear, labeled and ANSI-free. Real subprocess assertions cover
the exact five human lines, four-field JSON, success/error streams and help examples.
No screen-reader study, GUI check or native Windows execution is claimed.

## Acceptance checklist and ownership

- [x] Required behavior, uncertainty, five limits and negative effects independently
  inspected and exercised; executable test mapping retained.
- [x] Three exact Cargo gates pass on identical final sources.
- [x] Required TCP test rerun unchanged after the environment change.
- [x] Harness run unchanged without skips; actual exit 1 and coverage gap retained.
- [x] Migration and harness bytes compared with baseline; all 64 tracked/untracked
  resulting Rust source/test files are <=500 lines (maximum 474).
- [x] Input/post-check hashes, complete logs, context, source inventory and scalar
  verification summary written under assigned paths.
- [x] No product/test/specification/mission edits, ownership conflict or interface
  incompatibility found. Repairs are unnecessary; affected receipts would need
  rerunning if source inputs change.

## Remaining obligations

Coverage is unresolved at scripts/harness/validate.sh:420, where the unchanged
`bun run test:coverage` reports a missing script. Chief should retain this failure
and coordinate any future coverage work outside this review; no dummy tooling,
skip or altered acceptance command was added. No measured coverage percentage is
available from this run.

The delivered detector is the documented syntax subset. Wider detector catalogs,
dialects, scripts and actual endpoint/locality resolution, scheduling,
managed-execution, desktop and native Windows acceptance remain open. Chief-owned
final-report.md/final-summary.json and framework final verification are downstream
responsibilities. This review creates no replacement final-mission approval.
