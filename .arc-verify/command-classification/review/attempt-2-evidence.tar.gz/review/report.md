# Review Result: FAIL

Independent QA Reviewer, task-5 attempt 2. Skill used: oma-qa, including its
execution protocol and shared execution policy. Review completeness: completed;
mission behavioral acceptance: failed. No product code, tests, manifests, lockfile,
contract, migration, harness, mission state or other Actors' reports were edited.
Only review/ and verification/ under .arc-verify/command-classification/ changed.
The preceding review evidence is retained in review/attempt-1-evidence.tar.gz.
That historical PASS is superseded by this reproducible finding.

## HIGH

- **SSH-POST-DESTINATION — crates/arc-detector/src/rules.rs:69** (related lines
  79 and 90): SSH options immediately after a destination are incorrectly treated
  as remote command text. ssh_forwarding stops at the destination; ssh then accepts
  any remaining nonempty word as a remote command. Literal inputs `ssh build01 -N`
  and `ssh build01 -G` both return REMOTE_EXEC/REMOTE/SSH_REMOTE_COMMAND/NONE.
  Compounds `cargo test && ssh build01 -N` and the corresponding -G input return
  MIXED/MIXED/COMPOUND_MIXED/NONE. These must remain UNKNOWN/UNKNOWN/OBSERVE
  while post-destination option semantics are unresolved.

The unchanged implementation was independently exercised through protocol-1
job.classify and both real arcctl output modes. The retained probe has 17 synthetic
cases: 11 fail expectations, six controls pass. Forwarding flags -L/-R/-D/-W and
quoted '-N' also fail after the destination. Quoting removes shell interpretation
but does not stop SSH option parsing. Real remote-command controls (`make -N` and
quoted `make -N`), explicit -- termination before/after the destination, a preceding
-N switch, and a quoted command-like local argument behave as expected.

Evidence: verification/ssh-post-destination.py, .json and .txt. The JSON retains
exact inputs, expected fields, actual IPC envelopes, human/JSON CLI argv and complete
outputs, binary hashes, source hashes, timestamps, effective context and owned-child
exit/runtime accounting. The command exits 1 for the eleven mismatches. Only
arc-daemon and arcctl are started; synthetic SSH command strings are submitted as
data. No SSH process, real host or analyzed endpoint is used.

The upstream [OpenSSH argument parser](https://github.com/openssh/openssh-portable/blob/master/ssh.c#L1041-L1085)
was read during this review: it reparses options after selecting the destination
unless -- has terminated option parsing. Its -N case selects no session; -G selects
configuration output. This supports conservative uncertainty for these inputs.
The source observed through the official raw URL carries OpenBSD revision 1.647,
dated 2026-11-02. This is source evidence, not a claim about an SSH process executed
by this review.

Remediation belongs to backend. Preserve charged work accounting, honor explicit
--, reject unresolved post-destination options before selecting REMOTE_EXEC, and
keep arguments opaque after an actual remote command starts. One narrow candidate
for the existing restricted parser is the following replacement for its trailing
word inspection. This is review advice, not an applied or validated repair:

```rust
let mut command = &words[index + 1..];
if index == 0 { // no explicit -- before the destination
    if let Some(first) = command.first() {
        if b.eq(first, "--")? {
            command = &command[1..];
        } else {
            b.charge(1)?;
            if first.starts_with('-') {
                return unknown(R::SshAmbiguous);
            }
        }
    }
}
let mut nonempty = false;
for word in command {
    b.charge(2)?;
    nonempty |= !word.is_empty();
}
if !nonempty {
    return unknown(R::SshAmbiguous);
}
```

Backend must validate the full parser behavior and add permanent deterministic
regressions to crates/arc-detector/src/tests.rs, crates/arc-ipc/tests/classification.rs
and crates/arc-daemon/tests/classification.rs, including actual human/JSON CLI
assertions. Include post-destination -N/-G/forwarding, compounds, quoted flag tokens,
explicit -- and opaque remote-command controls. No tests were changed here. Any
repair changes source hashes and invalidates the affected passing receipts; rerun
required verification and independent QA before clearing the blocker.

## Other severities

No additional CRITICAL, HIGH, MEDIUM or LOW defect was confirmed in this inspection.
The harness coverage failure below is a retained acceptance limitation, not a new
classifier defect. The confirmed HIGH issue prevents PASS.

## Source and interface inspection

Actual HEAD and accepted baseline are both
05f0812d0841485bbe07b3f1f8f6fde3861a1d55. Existing uncommitted tracked and untracked
implementation was inspected first, including the rejected preceding review,
amended contract pair, synchronized CLI requirements and implementation handoff.
All 79 independently inventoried source/config/specification inputs remain equal
before and after checks. The preceding implementation inventory's 77 hashes match.
All 64 resulting tracked/untracked Rust source/test files have at most 500 lines;
maximum 474. See verification/source-inventory.json for every path, SHA-256, line
count, tracking status, mode and baseline invariant comparison.

The detector depends only on Serde in production. Its call path is in-memory
scan/parse/recognize/aggregate; there is no shell/process, filesystem, environment,
network, tool-discovery, logging, storage or cache API. Input bytes, tokens,
invocations, active nested groups/wrappers and charged work are bounded. Checked
addition rejects work before an overrun; nested parsing shares counters. The
65536 work primitive, overflow and end-to-end production exhaustion tests pass.
The trace records 12033 bytes, work 60203, six tokens, two invocations and depth one
before a bulk charge is refused; other caps remain below their limits.

Protocol remains 1; the dispatch(request, doctor) signature remains compatible.
Version rejection precedes typed payload decoding. Daemon classification completes
synchronously under existing request admission, drops decoded input on dispatch
return and replaces request.payload with null before response await. Classification
does not enter DbWorker. Existing status/doctor outputs and diagnostics not_checked
semantics pass unchanged. Native peer UID authentication, admission, limits and
lifecycle files match baseline bytes; no new bypass path was found. Runtime limits
remain 64 connections, 16 requests, queue eight, frame 1048576 bytes, shutdown
3500 ms. No live foreign-account impersonation or native Windows check is claimed.

## Commands executed and outcomes

All commands ran in the mission workspace through supported noninteractive
exec_command on macOS arm64, effective UID 501. Cargo was offline. The core check
runner was serial, with 120-second command timeouts. Supplemental trace/probe
commands overlapped the harness only; there were no overlapping daemon test loads.
No browser, GUI, download, installation, standalone build, policy bypass or external
delivery occurred. Exact argv, cwd, execution context, timestamps, actual exits,
complete combined logs and before/after hashes are in verification/*.json/.txt.

| Command | Actual outcome |
| --- | --- |
| Fresh socket.bind/listen 127.0.0.1:0, then close owned socket | Permitted; the operator environment change is effective |
| cargo test -p arc-daemon --test classification privacy::required_loopback_endpoint_nonexecution_and_privacy -- --exact | Exit 0; unchanged test passed |
| cargo fmt --all -- --check | Exit 0 |
| cargo clippy --workspace --all-targets -- -D warnings | Exit 0 |
| cargo test --workspace | Exit 0; 205 passed, zero failed/ignored |
| ./scripts/harness/validate.sh | Exit 1; Script not found "test:coverage"; one violation; no skip |
| cargo test -p arc-detector tests::production_work_exhaustion_trace -- --exact --nocapture | Exit 0; one passed; counter trace retained |
| python3 .arc-verify/command-classification/verification/ssh-post-destination.py | Exit 1; 11/17 expectations fail through real IPC and both CLI modes |
| git diff --check -- Cargo.toml Cargo.lock crates scripts/harness | Exit 0; no whitespace errors |

The failing behavioral probe is independent of the passing workspace suite. Existing
SSH tests cover pre-destination flags and opaque option values but miss this option
position, so the 205 passing tests do not establish full behaviorVerified.

## Negative effects and operational evidence

The required TCP privacy test remains byte-identical with every assertion intact
(SHA-256 3c7fd3ba43eded12ddaa071cbce6553c05370fe3898f4034912a6653620eadee).
It was rerun after a fresh permitted TCP prerequisite probe. Both Unix and TCP
privacy tests pass in the full suite. Each exercises 12 families through actual
daemon IPC and human/JSON CLI subprocesses, executable traps, active/literal/nested/
backtick substitutions, monitored endpoints and synthetic secrets. Captured daemon
logs, reports, database and live WAL/SHM are checked before/during/after shutdown.
Fresh receipts report zero tool traps, substitution markers, endpoint contacts and
persisted canaries. Classification-only database high-water is zero. Source purity
supports these probes; no universal shell-runtime claim is made.

Fresh saturation evidence records 91 classifications, continuing load, malformed
same-connection recovery in 10205 microseconds, maximum health latency 8564
microseconds over ten successful health observations, and SIGTERM-to-exit 6311
microseconds. Handler/worker accounting, zero gauges, socket removal and the
3500000-microsecond shutdown bound pass. These are one debug-run measurements.
Real daemon and CLI contract matrices, fake-peer malformed/correlation/timeout
cases and existing authentication/admission/deadline/shutdown tests pass. Exact
executable names and obligation mappings are in verification/test-matrix.md.

## Acceptance checklist and handoff to Chief

- [ ] Full behavior and conservative uncertainty: blocked by SSH-POST-DESTINATION.
- [x] Exact fmt/clippy/workspace gates executed and passing on identical source inputs.
- [x] TCP prerequisite and unchanged mandatory privacy test pass in current context.
- [x] Protocol/status/doctor/authentication/admission/health/shutdown preservation inspected and exercised.
- [x] Migration and harness byte-equal to baseline; complete resulting Rust inventory within 500 lines.
- [x] Harness executed unchanged; actual exit 1 and unresolved coverage retained.
- [x] Independent report, truthful scalar summaries, logs, hashes and executable matrix produced.
- [ ] Backend repair, permanent regressions and fresh affected QA required before blockersResolved=true.

Changed paths are only .arc-verify/command-classification/review/ and verification/.
No ownership or wire-interface conflict was found. The requested repair is outside
review ownership and must return to backend through Chief coordination. No operator
implementation choice or new approval is required.

Coverage remains unresolved at the unchanged harness's bun run test:coverage gate.
Remaining wider detector catalogs/dialects/scripts/actual locality resolution,
scheduling, managed-execution, desktop and native Windows acceptance remain open.
Chief-owned final-report.md, final-summary.json and framework mission verification
are downstream; this review does not modify or certify them.

Serena tools were unavailable, so inspection used known-path reads and Git diff,
without native project code-content discovery. Global status reports av.yaml access
denied; no globally clean worktree claim or bypass was made. mise emits a tracked-
config link warning; the permitted checks complete. Review summaries explicitly
record behaviorVerified=false and blockersResolved=false. The stale PASS is
preserved only as historical evidence in the attempt archive.
